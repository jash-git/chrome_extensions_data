[].map.call(document.getElementsByTagName('img'), function(img){
  return img.src;
});
