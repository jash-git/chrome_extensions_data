Chrome扩展及应用开发
====================

![Chrome扩展及应用开发](http://www.ituring.com.cn/download/01g5ecFVoWUi)

您可以通过以下渠道获得本书：

+ 免费但未经编辑的首发电子版：<http://www.ituring.com.cn/book/1421>，支持推送至Kindle及在线阅读
+ 经过编辑精心编辑的，内容更加充实且排版更加精美的电子版：<http://www.ituring.com.cn/book/1472>，支持推送至Kindle、下载完整PDF及在线阅读
+ 经过编辑精心编辑的，内容更加充实且排版更加精美的纸版：
  + 京东：<http://item.jd.com/11545545.html>
  + 亚马逊：<http://www.amazon.cn/dp/B00NN8GIX4>
  + 当当：<http://product.dangdang.com/23566522.html>
  + 互动出版网：<http://product.china-pub.com/3804069>

您可以通过以下渠道了解本书：

+ 豆瓣：<http://book.douban.com/subject/25980975>
+ 51CTO：<http://book.51cto.com/art/201409/451014.htm>

另外，您通过<http://www.ituring.com.cn/book/1472>购买的电子版费用中，作者所得的全部收入都将由人民邮电出版社代捐给壹基金，感谢您对慈善事业的支持。
